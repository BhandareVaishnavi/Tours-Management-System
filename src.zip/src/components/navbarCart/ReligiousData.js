const ReligiousData = [
    {
      city: 'Varanasi',
      rate: '15,999/-',
      flights: '2 flights',
      hotels: '3 hotels',
      activities: '5 activities',
      transfers: '4 transfers',
      imageSrc: './assets/images/tours/varanasi.jpg',
    },
    {
        city: 'Amritsar',
        rate: '18,777/-',
        flights: '2 flights',
        hotels: '3 hotels',
        activities: '6 activities',
        transfers: '5 transfers',
        imageSrc: './assets/images/tours/amritsar.jpg',
      },
      {
        city: 'Rishikesh',
        rate: '21,999/-',
        flights: '2 flights',
        hotels: '4 hotels',
        activities: '7 activities',
        transfers: '6 transfers',
        imageSrc: './assets/images/tours/rishikesh.jpg',
      },
      {
        city: 'TamilNadu',
        rate: '18,777/-',
        flights: '2 flights',
        hotels: '3 hotels',
        activities: '6 activities',
        transfers: '5 transfers',
        imageSrc: './assets/images/tours/tamilnadu.jpg',
      },
      {
        city: 'Bihar',
        rate: '21,999/-',
        flights: '2 flights',
        hotels: '4 hotels',
        activities: '7 activities',
        transfers: '6 transfers',
        imageSrc: './assets/images/tours/bihar.jpg',
      },
   
    
  ];
  
  export default ReligiousData;
  