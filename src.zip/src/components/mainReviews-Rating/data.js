const stars = [
  {
    id: 1,
    stars: 4.5,
  },
];

export default stars;
